
from django.urls import path, include
from . import views
urlpatterns = [

    path('', views.home, name="home"),
path('', views.contact, name="contact"),
path('', views.about, name="about"),
path('bookings', views.bookings, name="bookings"),
path('appointments', views.appointments, name="appointments"),
path('served', views.served, name="served"),
path('booking/<pk>', views.booked, name="booked"),
path('serve/<pk>', views.serve, name="serve"),
path('reject/<pk>', views.reject, name="reject"),
path('rejected', views.rejected, name="rejected"),


]