from django.shortcuts import render, redirect, reverse
from . models import Booking
from datetime import date, datetime, time
from django.contrib.auth.decorators import login_required
# Create your views here.
def home(request):
    return render(request, 'home.html')
def about(request):
    return render(request, 'home.html')

def contact(request):
    return render(request, 'home.html')


def bookings(request):
    if request.method == "POST":
        name=request.POST.get('name')
        time = request.POST.get('time')
        date = request.POST.get('date')
        data = Booking()
        data.name= name
        data.time = time
        data.date = date
        data.save()
        pk=Booking.objects.filter().last()
        id=pk.id
        return redirect(reverse('booked', kwargs={'pk': id}))


    return render(request, 'bookings.html')

@login_required
def appointments(request):
    appointments=Booking.objects.filter(status=False)
    context={
        'appointments':appointments
    }

    return render(request, 'appointments.html', context)
@login_required
def served(request):
    appointments=Booking.objects.filter(status=True)
    context={
        'appointments':appointments
    }

    return render(request, 'served.html', context)

def booked(request, pk):
    appointments=Booking.objects.get(id=pk)
    context={
        'i':appointments
    }

    return render(request, 'booked.html', context)

@login_required
def rejected(request):

    return render(request, 'rejected.html')

@login_required
def reject(request, pk):
    appointments=Booking.objects.get(id=pk)
    id=appointments.id
    if request.method == "POST":
        appointments.delete()
        return redirect('rejected')
@login_required
def serve(request, pk):
    appointments=Booking.objects.get(id=pk)
    if request.method == "POST":
        appointments.status=True
        appointments.timestamp=datetime.now()
        appointments.save()
        return redirect('served')

